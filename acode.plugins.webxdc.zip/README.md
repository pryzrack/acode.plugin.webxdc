# Webxdc Template

This plugin facilitates the creation of Webxdc applications.

### Note
This plugin is in the testing phase (betha).